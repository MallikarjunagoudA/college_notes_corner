 <footer class="foo">
 	<link rel="stylesheet" type="text/css" href="index.css">
 	

            <div class="row">
                <div class="col-lg-12">

                    <h3>
                            <center> <marquee width = 30% ><font> BIET-DAVANGERE 2019 COLLEGE NOTES CORNER</font></marquee></center>
                        </h3>
                        <h1>Web Technology Mini Project</h1>
                </div>
            </div>
   </footer>