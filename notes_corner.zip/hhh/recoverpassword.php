
<?php

$conn = mysqli_connect("localhost","root","","notes" );

if($_POST)
{
  $email=$_POST['email'];
$sq=mysqli_query($conn, "select * from users where email='{$email}'") or die(mysqli_error($conn));
$c = mysqli_num_rows($sq);
$row = mysqli_fetch_array($sq);
if($c >0)
{


require 'PHPMailer/PHPMailerAutoload.php';

$mail = new PHPMailer(true);

$mail->SMTPDebug = 0;
$mail->isSMTP();                            // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';             // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                     // Enable SMTP authentication
$mail->Username = 'xamp74@gmail.com';          // SMTP username
$mail->Password = 'xamp74xamp'; // SMTP password
$mail->SMTPSecure = 'ssl';                  // Enable TLS encryption, `ssl` also accepted
$mail->Port = 465;                          // TCP port to connect to

$mail->setFrom('xamp74@gmail.com', 'Admin');
$mail->addReplyTo('xamp74@gmail.com', 'Admin');
$mail->addAddress($email, $email);

$mail->isHTML(true);  // Set email format to HTML
$mail->Subject = 'Email from college notes corner ';
$mail->Body    = "hello {$row['name']} your email is $email and  your password is {$row['password']}. please dont forword or share this mail and aslo don't REPLAY to this mail";


$mail->send();

echo "YOUR PASSWORD HAS BEEN SENT TO YOUR EMAIL ACCOUNT,  PLEASE DONOT SHARE IT";
}
else
{
 echo "PLEASE PROVIDE THE VALID EMAIL ID";
}

}
?>

  <link rel="stylesheet" type="text/css" href="css/forgetcss.css">   
</head>
    <body>
    <div class="login-box">
    <img src="images/avatar.png" class="avatar">

  
    <h1>Recover Password</h1><br>
  <form method="POST">
    <input type="text" name="email" placeholder="abc@gmil.com" required="">
    <input type="submit" name="login" value="send">
  </form>   
  <div class="login-help">
    <a href="login.php"><b>&nbsp &nbsp &nbsp &nbsp  LOGIN</b></a>&nbsp &nbsp  <b>•</b>  &nbsp &nbsp <a href="signup.php"><b>SIGNUP</b></a>
  </div>
</div>  
</body>
</html>
 
